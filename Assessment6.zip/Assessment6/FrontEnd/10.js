function squareNums(numbers) {
    return numbers.map(num => num * num);
}

const numbers = [1, 2, 3, 4, 5];
const squaredNums = squareNums(numbers);
console.log(squaredNums);
