﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleNumber
{
    class Q5
    {
        class Student
        {
            public int ID { get; set; }
            public string Name { get; set; }
        }

        class Enrollment
        {
            public int StudentID { get; set; }
            public string Course { get; set; }
        }

        static void Main()
        {
            List<Student> students = new List<Student>
        {
            new Student { ID = 101, Name = "Vasu" },
            new Student { ID = 102, Name = "Kishor" },
            new Student { ID = 103, Name = "Vamshi" }
        };

            List<Enrollment> enrollments = new List<Enrollment>
        {
            new Enrollment { StudentID = 101, Course = "DataAnalysis" },
            new Enrollment { StudentID = 102, Course = "DataScience" },
            new Enrollment { StudentID = 103, Course = "BlockChain" },
            new Enrollment { StudentID = 102, Course = "SQL" }
        };

            var studentCourses = from student in students
                                 join enrollment in enrollments
                                 on student.ID equals enrollment.StudentID
                                 select new
                                 {
                                     student.ID,
                                     student.Name,
                                     enrollment.Course
                                 };

            foreach (var sc in studentCourses)
            {
                Console.WriteLine($"Student: {sc.Name} (ID: {sc.ID}) - Course: {sc.Course}");
            }
        }
    }
}
