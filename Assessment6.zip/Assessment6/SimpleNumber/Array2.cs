﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleNumber
{
    internal class Array2
    {
        static void Main()
        {
            int[] numbers = { 3, 5, 7, 2, 8, 6 };

            int sum = 0;
            int max = numbers[0];
            int min = numbers[0];

            foreach (int number in numbers)
            {
                sum += number;
                if (number > max) max = number;
                if (number < min) min = number;
            }

            double average = (double)sum / numbers.Length;

            Console.WriteLine($"Sum: {sum}");
            Console.WriteLine($"Average: {average}");
            Console.WriteLine($"Maximum: {max}");
            Console.WriteLine($"Minimum: {min}");
        }
    }
}
